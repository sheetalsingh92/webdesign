function displayAppleBenfits(){
	
	document.getElementById("appleframe").style.display = "block";
	
}

function displayOrangeBenfits(){
	
	document.getElementById("orangeframe").style.display = "block"
	
}