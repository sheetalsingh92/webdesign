<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<title>Comments</title>
</head>
<body>
<?php

# Created February 2, 2005
# Created by Larry E. Ullman
# This script does nothing much.

echo "This echo() statement runs 
over the course of two lines!";

/*
echo "<br />This line should appear separately in the Web page.\n\n";
*/

echo 'Now I\'m done.'; // End of PHP code.

?>
</body>
</html>