var app = angular.module("shoppingList",[]);
app.controller("shoppingController", function($scope){
	$scope.items =[{ name : 'Apple', quantity : 1 , cost : 5}];
	

});